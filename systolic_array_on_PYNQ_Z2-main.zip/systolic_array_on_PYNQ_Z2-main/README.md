# systolic_array_on_PYNQ_Z2
build systolic_array on PYNQ_Z2 board. Not optimal version, in case of communication, data flow structure, or timing (achieve low clock frequency) NOW.

## version 1 is project 2
### version 1.0.0
#### WS or OS calculation of (1x1 ~ 8x8) and (1x1 ~ 8x8).

## From here project 3
### version 1.5.0
#### WS or OS calculation with padding

### version 1.6.0
#### in WS M can be bigger than 8 (~50)

### version 1.7.0
#### in WS K can be bigger than 8 
#### in OS, K is bigger than 8

### version 1.8.0
#### in WS and N is bigger than 8 
##### However, when N > 8, sometimes error occer, from 1st contents diff value out.

### version 1.9.0
#### in OS, M and N is bigger than 8 
